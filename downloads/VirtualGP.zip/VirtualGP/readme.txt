DST II Final Project
GUITAR EFFECTS PROCESSOR
Hariharan Mohanraj
hm992@nyu.edu


Instructions/Directions/Suggestions
1. Be sure to click the button on the top left before you turn on DSP.
2. DSP controls are at the bottom of the patch.
3. Effects have been slotted into subpatches, click each one to open them.
4. The PD patch should capture audio from your primary recording device, so make sure to set your guitar input as your default device on your machine.
5. You can also drive the input with audio files from your machine. Make sure to change the path name to something valid before doing so.
6. For distortion patches, I got cool sounds with high input gains (5 - 10), subtle parameters (either close to 1 or 0), and low output gains.
BE CAREFUL, IT GETS LOUD.

Enjoy!